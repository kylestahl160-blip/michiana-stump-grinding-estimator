'use client';
import Estimator from '../components/Estimator';
export default function Page() { return <Estimator />; }
