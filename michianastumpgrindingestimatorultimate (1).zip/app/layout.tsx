export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin:0, background:'#020617', color:'white', fontFamily:'system-ui' }}>
        {children}
      </body>
    </html>
  );
}


import './globals.css'

export const metadata = {
      generator: 'v0.app'
    };
