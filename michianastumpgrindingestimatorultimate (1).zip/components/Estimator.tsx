"use client"
import { useState } from "react"
import { motion } from "framer-motion"

const PRO_PIN = "6868"

export default function Estimator() {
  const [width, setWidth] = useState("")
  const [count, setCount] = useState("")
  const [price, setPrice] = useState<number | null>(null)
  const [cleanup, setCleanup] = useState(false)
  const [pro, setPro] = useState(false)
  const [pin, setPin] = useState("")
  const [photos, setPhotos] = useState<FileList | null>(null)

  const basePrice = (inches: number) => {
    if (inches <= 12) return 110
    if (inches <= 24) return 195
    if (inches <= 36) return 325
    return 325 + (inches - 36) * 8
  }

  const calculate = () => {
    const w = Number(width)
    const c = Number(count)
    if (!w || !c) return setPrice(null)

    let total = basePrice(w)
    if (c >= 2) total *= 0.9
    if (cleanup) total += total * 0.35
    if (pro) total *= 0.85
    setPrice(Math.max(125, Math.round(total)))
  }

  const unlock = () => {
    if (pin === PRO_PIN) setPro(true)
  }

  const logout = () => {
    setPro(false)
    setPin("")
  }

  const smsBody = () => {
    return encodeURIComponent(
      `Stump Grinding Estimate Request
Total Width: ${width}"
Stump Count: ${count}
Cleanup: ${cleanup ? "Yes" : "No"}
Estimated Total: $${price}
50% deposit required to schedule`,
    )
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: 20,
        backgroundImage: "url('/images/screenshot-20260102-084649.png')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        position: "relative",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: "rgba(0, 0, 0, 0.6)",
          zIndex: 0,
        }}
      />

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        style={{
          maxWidth: 440,
          width: "100%",
          border: "2px solid #3b82f6",
          borderRadius: 22,
          padding: 20,
          position: "relative",
          zIndex: 1,
          background: "white",
          boxShadow: "0 10px 40px rgba(0, 0, 0, 0.5)",
        }}
      >
        <h1 style={{ fontSize: 22, fontWeight: 800, color: "#1e293b" }}>Michiana Stump Grinding Estimator</h1>

        {pro && (
          <div
            style={{
              marginTop: 10,
              padding: 10,
              background: "#dbeafe",
              border: "1px solid #3b82f6",
              borderRadius: 8,
              fontSize: 13,
              color: "#1e40af",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <strong>Pro Mode Active - 15% Discount Applied</strong>
            <button
              onClick={logout}
              style={{
                padding: "4px 12px",
                background: "#ef4444",
                color: "white",
                border: "none",
                borderRadius: 6,
                fontSize: 12,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              Logout
            </button>
          </div>
        )}

        <p style={{ fontSize: 13, color: "#475569", marginTop: 8 }}>
          Enter total stump width(s) in inches measured at the widest point. Add all stump widths together.
        </p>

        <input
          style={input}
          placeholder="Total width (inches)"
          value={width}
          onChange={(e) => setWidth(e.target.value)}
        />
        <input style={input} placeholder="Number of stumps" value={count} onChange={(e) => setCount(e.target.value)} />

        {Number(count) >= 2 && (
          <div
            style={{
              marginTop: 10,
              padding: 10,
              background: "#dcfce7",
              border: "1px solid #22c55e",
              borderRadius: 8,
              fontSize: 13,
              color: "#166534",
            }}
          >
            <strong>✓ Multi-Stump Discount Applied!</strong> Save 10% on 2+ stumps
          </div>
        )}

        <label style={label}>
          <input type="checkbox" checked={cleanup} onChange={(e) => setCleanup(e.target.checked)} />
          Full cleanup, haul-off, backfill & seed (35% of total)
        </label>

        <input
          type="file"
          multiple
          accept="image/*"
          onChange={(e) => setPhotos(e.target.files)}
          style={{ marginTop: 10 }}
        />

        <button style={btn} onClick={calculate}>
          Calculate Estimate
        </button>

        {price && (
          <div style={{ marginTop: 15, padding: 15, border: "1px solid #3b82f6", borderRadius: 12 }}>
            <h2 style={{ fontSize: 28, color: "#1e293b" }}>${price}</h2>
            <div style={{ marginTop: 5, fontSize: 12 }}>
              {Number(count) >= 2 && (
                <p style={{ color: "#22c55e", fontWeight: 600, margin: "2px 0" }}>
                  ✓ 10% multi-stump discount included
                </p>
              )}
              {pro && <p style={{ color: "#3b82f6", fontWeight: 600, margin: "2px 0" }}>✓ 15% pro discount included</p>}
            </div>
            <p style={{ fontSize: 13, color: "#475569", marginTop: 8 }}>50% deposit required to schedule</p>
            <a style={btn} href={`sms:5743789275?body=${smsBody()}`}>
              Book via Text
            </a>
          </div>
        )}

        {!pro && (
          <div style={{ marginTop: 15 }}>
            <input style={input} placeholder="Pro PIN" value={pin} onChange={(e) => setPin(e.target.value)} />
            <button style={btn} onClick={unlock}>
              Unlock Pro
            </button>
          </div>
        )}

        <div style={{ fontSize: 12, color: "#64748b", marginTop: 15 }}>
          Stumps ground approx. 6–8 inches below grade. Final pricing subject to site conditions. Customer responsible
          for utility locates. Minimum charge $125.
        </div>
      </motion.div>
    </div>
  )
}

const input = {
  width: "100%",
  padding: 10,
  marginTop: 10,
  borderRadius: 8,
  border: "1px solid #cbd5e1",
  color: "#1e293b",
  fontSize: 14,
}
const btn = {
  display: "block",
  width: "100%",
  marginTop: 12,
  padding: 10,
  borderRadius: 8,
  background: "#2563eb",
  color: "white",
  textAlign: "center" as const,
  fontWeight: 700,
  border: "none",
  cursor: "pointer",
}
const label = {
  display: "flex",
  gap: 8,
  fontSize: 13,
  marginTop: 10,
  color: "#475569",
  alignItems: "center",
}
